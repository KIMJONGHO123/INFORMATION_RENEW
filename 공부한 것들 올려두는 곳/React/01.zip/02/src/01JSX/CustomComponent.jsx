const CustomComponent = () => {
  return <h2>CUSTOM - COMPONENT</h2>;
};

export default CustomComponent;
