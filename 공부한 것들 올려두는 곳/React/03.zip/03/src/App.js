import MyComponent from "./02COMPONENT/MyComponent";

function App() {
  return (
    <>
      <div className="App">
        <MyComponent></MyComponent>
      </div>
    </>
  );
}

export default App;
